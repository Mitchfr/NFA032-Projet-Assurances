package assur_package;

 abstract class Contrat {
	
	public abstract void Saisie();			// M�thode pour la saisie des information
	public abstract void Imprimer();		// Methode pour l'affichage des contrats
	public abstract void CalculTarif();
	
}
