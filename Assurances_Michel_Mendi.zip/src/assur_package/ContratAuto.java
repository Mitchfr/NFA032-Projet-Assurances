package assur_package;

public  class ContratAuto  {
	
	private double bonsuMalus;						// variable pour le bonus/malus
	private int nbAnAssurance;						//  variable pour nombre d'ann�e d'assurance
	private int nbChevaux;							// variable pour le nombre de chevaux
	private double majChevauxTab;					//  variable pour  la majoration par rapport au nombre de chevaux fiscaux
	private double nbAnTab;							//  variable pour la majoration en fonction du nombre d'ann�es d'assurance
	private double conjointTab;						//  variable pour la majoration si le client a un conjoint
	private double enfantsTab;						//  variable pour la majoration si le client a des enfants
	private double reductionTab;					//  variable pour retourner le nombre d'ann�e d'assurance
	int baseAuto = 20;
	

	double [] majChevauxFiscaux = {1,1.1,1.2,1.3,1.4,1.5,1.6};			// majoration par rapport aux chevaux fiscaux
	int [] anAssur 				= {0,1,2,3,4,5,6};						// R�duction En euros Quel que soit	Le	nombre	de chevaux
	int [] marieChevaux 		= {1,2,3,4,5,6,7};						// Majoration en euros En fonction du nombre de chevaux
	int [] enfantMajoration		= {1,2,3,4,5,6,7};						// majoration en euros En fonction du nombre de chevaux
	
/*
 * Definition du constructeur avec les variables � z�ro
 */
	 ContratAuto(){
			bonsuMalus=0;
			nbAnAssurance=0;
			nbChevaux=0;
			majChevauxTab=0;
			nbAnTab=0;
			conjointTab=0;
			enfantsTab=0;
			reductionTab=0;
	 }


	 /*
	  * Definition du constructeur avec les parametres saisies par l'utilisateur
	  */

	ContratAuto(int nbChevaux, double bonsuMalus, int nbAnAssurance, boolean conjoint, boolean enfants) {
		this.majChevauxTab=majChevauxFiscaux[nbChevaux-4];		// recupere la valeur dans le tableau 'majChevauxFiscaux'
		

		if (nbAnAssurance>6) {							// si le nombre d'ann�e est sup�rieure � 10 on garde la derni�re valeur du tableau
			this.reductionTab= anAssur[6];
			if (conjoint) {								// si il y a un conjopint ont recup�re la derniere valeur du tableau'marieChevaux'
				this.conjointTab=marieChevaux[6];
			}
			if (enfants) {								// si il y a des enfants  ont recup�re la  derniere valeur du tableau'marieChevaux'
				this.enfantsTab=enfantMajoration[6];
			}
		
		}
		
		else {											// si le nombre  d'ann�e est inferieure � 6 ont prend la valeur correspondante dans le tableau
			this.reductionTab= anAssur[nbAnAssurance];
			if (conjoint) {
				this.conjointTab=marieChevaux[nbChevaux-4];
			}
			if (enfants) {
				this.enfantsTab=enfantMajoration[nbChevaux-4];
			}
		}
		
		

		this.bonsuMalus=bonsuMalus;								// recupere la valeur dans le tableau 'majChevauxFiscaux'
		this.nbAnAssurance=nbAnAssurance;						// recupere la valeur du nombre d'ann�e d'assurance
		this.nbChevaux=nbChevaux;								// recupere la valeur du nombre de chevaux
		
	}




	public double getBonsuMalus() {
		return bonsuMalus;
	}




	public void setBonsuMalus(double bonsuMalus) {
		this.bonsuMalus = bonsuMalus;
	}




	public int getNbAnAssurance() {
		return nbAnAssurance;
	}




	public void setNbAnAssurance(int nbAnAssurance) {
		this.nbAnAssurance = nbAnAssurance;
	}




	public int getNbChevaux() {
		return nbChevaux;
	}




	public void setNbChevaux(int nbChevaux) {
		this.nbChevaux = nbChevaux;
	}




	public double getMajChevauxTab() {
		return majChevauxTab;
	}




	public void setMajChevauxTab(double majChevauxTab) {
		this.majChevauxTab = majChevauxTab;
	}




	public double getNbAnTab() {
		return nbAnTab;
	}




	public void setNbAnTab(double nbAnTab) {
		this.nbAnTab = nbAnTab;
	}




	public double getConjointTab() {
		return conjointTab;
	}




	public void setConjointTab(double conjointTab) {
		this.conjointTab = conjointTab;
	}




	public double getEnfantsTab() {
		return enfantsTab;
	}




	public void setEnfantsTab(double enfantsTab) {
		this.enfantsTab = enfantsTab;
	}




	public double getReductionTab() {
		return reductionTab;
	}




	public void setReductionTab(double reductionTab) {
		this.reductionTab = reductionTab;
	}




	public double[] getMajChevauxFiscaux() {
		return majChevauxFiscaux;
	}




	public void setMajChevauxFiscaux(double[] majChevauxFiscaux) {
		this.majChevauxFiscaux = majChevauxFiscaux;
	}




	public int[] getAnAssur() {
		return anAssur;
	}




	public void setAnAssur(int[] anAssur) {
		this.anAssur = anAssur;
	}




	public int[] getMarieChevaux() {
		return marieChevaux;
	}




	public void setMarieChevaux(int[] marieChevaux) {
		this.marieChevaux = marieChevaux;
	}




	public int[] getEnfantMajoration() {
		return enfantMajoration;
	}




	public void setEnfantMajoration(int[] enfantMajoration) {
		this.enfantMajoration = enfantMajoration;
	}

	public String toString() {
		 
        System.out.println(nbChevaux+","+  majChevauxTab+","+ reductionTab+","+ conjointTab+","+ enfantsTab+","+bonsuMalus+","+  nbAnAssurance);
		return null;


}




}
