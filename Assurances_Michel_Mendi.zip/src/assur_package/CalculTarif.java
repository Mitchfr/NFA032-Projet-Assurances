package assur_package;

abstract class CalculTarif  extends CalculTarifsContrats {
			
	 public static double tarifsAuto(int base, double  majChevaux, int nbChevaux, double getReductionTab, double  conjoint, double  enfants, double  bonMal) {
				
		 double resultat;
		 
		 /*
		  * Calccul du tarif pour un contrat auto
		  * on multiplie le tarif de base 'base' par le nombre de chevaux fiscaux 'majChevaux'
		  * ensuite on soustrait ce resultat � la valeur du tableau correspondant au nombre d'ann�e d'assurance 'getReductionTab'
		  * ensuite on addition ce resultat avec la valeur du tableau correspondant au conjoint 'conjoint'
		  * ensuite on addition ce resultat avec la valeur du tableau correspondant au conjoint 'enfants'
		  * et enfin  on multiplie ce resultat avec la valeur du bonus/malus 'bonMal'
		  */
		 
		resultat = bonMal*((((base*majChevaux)-getReductionTab)+conjoint)+enfants);
		System.out.println();
		
		return resultat;
	 }
	 
	 public static  double tarifsMoto(int base, double  majChevaux,  double  bonMal, int anAssur) {
		 
			
		 double resultat;
		 
		 /*
		  * Calccul du tarif pour un contrat Moto
		  * on multiplie le tarif de base 'base' par le nombre de chevaux fiscaux 'majChevaux'
		  * ensuite on soustrait ce resultat � la valeur du tableau correspondant au nombre d'ann�e d'assurance 'anAssur'
		  * ensuite on addition ce resultat avec la valeur du tableau correspondant au conjoint 'conjoint'
		  * ensuite on addition ce resultat avec la valeur du tableau correspondant au conjoint 'enfants'
		  * et enfin  on multiplie ce resultat avec la valeur du bonus/malus 'bonMal'
		  */
		 
		resultat = bonMal*((base*majChevaux)-anAssur);
		System.out.println();
		return resultat;
	 }
	 
	 public static double tarifsMaison(int base, double MajSurfaceTab, int majGrageTab, int nbPersonneMaison) {
		 
			
		 double resultat;
		 
		 /*
		  * Calccul du tarif pour un contrat maison
		  * on multiplie le tarif de base 'base' par le nombre de chevaux fiscaux 'MajSurfaceTab'
		  * ensuite on addition ce resultat avec la valeur du tableau correspondant au garage 'majGrageTab'
		  * ensuite on addition ce resultat avec la valeur du tableau correspondant au nombre de personne du foyer 'nbPersonneMaison'
		  */
		 
		resultat = ((base*MajSurfaceTab)+majGrageTab)+nbPersonneMaison;
		System.out.println();
		
		return resultat;
	 }
	 
	 
}
