package assur_package;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public abstract class Imprimer extends Saisie {
	
	
	 public static  void imprimerAuto(String nom,  String prenom, double tarif , boolean marie , boolean enfants ) {
		 				

		System.out.println("\n\nDEVIS ASSURANCE VOITURE\n\n");
		System.out.println("Nom : "+ nom);
		System.out.println("\nPr�nom : "+prenom);
		NumberFormat nf = new DecimalFormat("#.00");
		System.out.println("\nLe tarif � payer pour l�assurance voiture est de "+nf.format(tarif)+ " euros");
		System.out.println("\nVeuillez joindre :");
		System.out.println("\n - Copie de carte grise");
		System.out.println("\n - Copie de permis");
		
		if (marie) {
			System.out.println("\n - Copie permis conjoint");
		}
		if (enfants) {
			System.out.println("\n - Copie permis enfant");
		}
		System.out.println("\n - RIB");
		System.out.println("\n - Carte d�identit� assureur\n");
	 }
	 
	 public static  void imprimerMoto(String nom,  String prenom, double tarif) {
			

		System.out.println("\n\nDEVIS ASSURANCE MOTO\n\n");
		System.out.println("Nom : "+ nom);
		System.out.println("\nPr�nom : "+prenom);
		NumberFormat nf = new DecimalFormat("#.00");
		System.out.println("\nLe tarif � payer pour l�assurance moto est de "+nf.format(tarif)+ " euros");
		System.out.println("\nVeuillez joindre :");
		System.out.println("\n - Copie de carte grise");
		System.out.println("\n - Copie de permis moto");
		System.out.println("\n - RIB");
		System.out.println("\n - Carte d�identit� assureur\n");
	 }
	 
	 public static  void imprimerMaison(String nom,  String prenom, double tarif) {
			

		System.out.println("\n\nDEVIS ASSURANCE HABITATION\n\n");
		System.out.println("Nom : "+ nom);
		System.out.println("\nPr�nom : "+prenom);
		NumberFormat nf = new DecimalFormat("#.00");
		System.out.println("\nLe tarif � payer pour l�assurance habitation est de "+nf.format(tarif)+ " euros");
		System.out.println("\nVeuillez joindre :");
		System.out.println("\n - Contrat de location");
		System.out.println("\n - RIB");
		System.out.println("\n - Carte d�identit� assureur\n");
	 }
	 
}