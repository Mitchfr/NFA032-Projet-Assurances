package assur_package;

public class Accueil_Assurances {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Saisie.saisieInfos();					// Appelle de la m�thode 'Saisie'
		
	}

}
