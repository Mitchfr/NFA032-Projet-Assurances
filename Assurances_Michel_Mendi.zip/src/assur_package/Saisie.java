package assur_package;


import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Scanner;


/*
 * La classe 'Saisie' demande � l'utilisateur de saisir les informations necessaires
 * � l'�tablissement des contrat.
 * 
 * Ensuite, o nappelle les differents objets :
 * 		- Clients : permet de stocker les infos du client
 * 		- ContratAuto : permet de stocker les informations du contrat
 * 
 * et on utilise les classes suivantes : 
 * 		- CalculTarif : sert � calculer le tarif des differents contrats
 * 		- Imprime : Imprime les contrats
 */
public abstract class Saisie extends Contrat {
	

	private static String nom;						// variable pour le nom
	private static String prenom;					// variable pour le prenom
	private static String dateNaissance;			// variable pour la date de naissance
	private static boolean marie;					// variable de contr�le de saisie pour v�rifier si la personne est mari�/pacs� ou non 
	private static boolean enfants;					// variable de contr�le de saisie pour v�rifier  si la personnea des enfants
	static boolean aEnfants = false;				// variable qui v�rifie si la personne est mari�/pacs� ou non
	static boolean aConjoint = false;				// variable qui v�rifie si la personne a des enfants
	static int chevaux = 0;							// variable de contr�le de saisie pour le nombre de chevaux
	static int cylindree=0;							// variable pour connaitre la sylindr�e
	static double bonMal = 0.0;						// variable de contr�le de saisie pour le bonus/malus
	static int anAssur = 0;							// variable de contr�le de saisie pour le nombre d'ann�e d'assurance
	static boolean garage;							// variable pou valider si garage ou non
	static int surface;								//variable qui stocke la surface
	static int nbPersonneMaison;					//variable pour lr nombre de personne dans le foyer
	static boolean verfiSaisie=false;				// Sert � verifier si il y a une erreur dans la saisie
	


	

	static double majChevauxTab;					// Majoration en fonction du nombre de chevaux
	static double conjointTab;						// Majoration si conjoint en fonction du nb de chevaux 
	static double enfantsTab;						// Majoration si enfant en fonction du nb de chevaux
	static double reductionTab;
	/*
	 * Saisie des infos communes � tous les contrats
	 */
	public static void saisieInfos() throws InputMismatchException {
		int choix=0;								// variable pour le choix du menu
		
        
	System.out.println("db         ad88888ba    ad88888ba   88        88  8888888ba          db         888b      88    ,ad8888ba,   88888888888  ad88888ba   ");
	System.out.println("d88b       d8      8b   d8       8b  88        88  88       8b        d88b        8888b     88   d8       8b  88          d8       8b  ");
	System.out.println("d8'`8b      Y8,          Y8,          88        88  88      ,8P       d8'`8b       88 `8b    88  d8'            88          Y8,          ");
	System.out.println("d8'  `8b     `Y8aaaaa,    `Y8aaaaa,    88        88  88aaaaaa8P'      d8'  `8b      88  `8b   88  88             88aaaaa     `Y8aaaaa,    ");
	System.out.println("d8YaaaaY8b     -------8b,    ------8b,  88        88  88----88'       d8YaaaaY8b     88   `8b  88  88             88-----       ------8b,  ");
	System.out.println("d8--------8b           `8b          `8b  88        88  88    `8b      d8--------8b    88    `8b 88  Y8,            88                  `8b  ");
	System.out.println("d8'        `8b  Y8a     a8P  Y8a     a8P  Y8a.    .a8P  88     `8b    d8'        `8b   88     `8888   Y8a.    .a8P  88          Y8a     a8P  ");
	System.out.println("d8'          `8b   Y88888P      Y88888P     ` Y8888Y '   88      `8b  d8'          `8b  88      `888    ` Y8888Y '   88888888888   Y88888P    ");
        
        
		System.out.println("\n\n\nBienvenue dans le programme d'assurances\n\n");
	
		Scanner sc = new Scanner( System.in );
		
		/*
		 * Saisie du Nom
		 */
		do { 
			Scanner sc1 = new Scanner( System.in );
			try  {		
				System.out.print("Quel est votre nom ? : ");
				nom = sc1.next("^([a-zA-Z'�����������������[:blank:]-]{1,30})$");	// permet de saisr uniquement des lettre et caract�re utilis�s dans le nom
				verfiSaisie=true;
							
			  }    
			  catch (InputMismatchException e){				// message si erreur de saisie
				  System.out.println("#############          Erreur de saisie, il ne peut y avoir que des lettres");
				  verfiSaisie=false;
			  }
		}while (verfiSaisie==false);
						
		/*
		 * Saisie du pr�nom
		 */
		do { 
			Scanner sc1 = new Scanner( System.in );
			try  {		
				System.out.print("Quel est votre pr�nom ? : ");
				prenom = sc1.next("^([a-zA-Z'�����������������[:blank:]-]{1,30})$");     // permet de saisr uniquement des lettre et caract�re utilis�s dans le nom
				verfiSaisie=true;
							
			  }    
			  catch (InputMismatchException e){				// message si erreur de saisie
				  System.out.println("#############          Erreur de saisie, il ne peut y avoir que des lettres");
				  verfiSaisie=false;
			  }
		}while (verfiSaisie==false);
		
		/*
		 * Saisie de la date de naissance
		 */
		do { 
			Scanner sc1 = new Scanner( System.in );
			verfiSaisie=true;																// si la saisie est OK alors la valeur passe � 'true' sinon � 'false'
			try  {		
				System.out.print("Quel est votre date de naissance (jj/mm/aaaa) ? : ");
				dateNaissance = sc1.next("^([0-2][0-9]|3[0-1])/(0[1-9]|1[0-2])/[0-9]{4}$");	// verifie que le format est bien jj/mm/aaaa
				Calendar calendar = Calendar.getInstance(); 
				int ann=calendar.get( Calendar.YEAR );										// recup�re l'ann�e en cours
				int dateNai=Integer.parseInt(dateNaissance.substring(6, 10));				// recupere l'annee saisie par l'utilisateur
				if (dateNai>ann-16) {														// v�rifie que l'enfant a au moins 16ans
					System.out.println("#############          Il faut avoir au moins 16 ans !\n");
					  verfiSaisie=false;
				}
				if (dateNai>ann) {															// si l'ann�e de naissance est sup�rieure � l'ann� actuelle 
					System.out.println("#############          Je pense que vous n'�tes pas encore n�(e) !\n");
					  verfiSaisie=false;
				}
			  }    
			  catch (InputMismatchException e){												// si une erreur n'a pas �t� d�tect�e plus haut, alors on met un message d'erreur g�n�rique
				  System.out.println("#############          Erreur de saisie, vous ne respectez pas le format ou votre date est incoh�rente\n");
				  verfiSaisie=false;
			  }
		}while (verfiSaisie==false);														// boucle tant que la sasie est erronn�e
	

	
			
		/*            ******  MENU   *************
		 *  permet de choisir le type de contrat
		 */
		do{
			Scanner sc2 = new Scanner( System.in );
			verfiSaisie=true;
			try  {	
				System.out.print("Quel contrat souhaitez-vous (1 : Voiture : 2 : Moto : 3 : Habitat) ? : ");
				choix = sc2.nextInt();				// variable 'choix' qui permet de stocker le choix de l'utilisateur
				switch (choix) {
					case 1 : 						// si choix 1 --> Voiture
						System.out.println("\n*************************    CONTRAT VOITURE     ******************************\n");	
						/*
						 * Saisie qui demande si la personne est mari�e/pacs�e
						 */
						
						char estMarie;
						do {
							System.out.print("Etes vous mari�/pacs� ? (O)ui ou (N)on: ");
							estMarie = sc.next().charAt(0);
							if (estMarie!='o' && estMarie!='O' && estMarie!='n' && estMarie!='N' ) {				//Message d'erreur si la saisie ne correspond pas
								System.out.println("\n#############          Il faut r�pondre par Oui ou par Non - O ou N\n");
							}
						}while (estMarie!='o' && estMarie!='O' && estMarie!='n' && estMarie!='N' );					// on boucle tant que la saisie n'est pas conforme
						if (estMarie=='o' || estMarie=='O'){				// si la r�ponse est 'Oui' � mari�, la variable 'marie' = true sinon 'false'
							marie=true;
						}
						else {
							marie=false;
						}
						
						/*
						 * Saisie qui demande si la personne a des enfants
						 */
						
						char estEnfants;
						do {
							System.out.print("Avez vous des enfants ? : ");
							estEnfants = sc.next().charAt(0);
							if (estEnfants!='o' && estEnfants!='O' && estEnfants!='n' && estEnfants!='N' ) {				//Message d'erreur si la saisie ne correspond pas
								System.out.println("\n#############          Il faut r�pondre par Oui ou par Non - O ou N\n");
							}
						}while (estEnfants!='o' && estEnfants!='O' && estEnfants!='n' && estEnfants!='N' );				// on boucle tant que la saisie n'est pas conforme
						if (estEnfants=='o' || estEnfants=='O'){				// si la r�ponse est 'Oui' � mari�, la variable 'marie' = true sinon 'false'
							enfants=true;
						}
						else {
							enfants=false;
						}
						
						/*
						 * Construction de l'objet 'clients' qui sera accessible � tout moment dans le programme
						 */
						Clients clients = new Clients(nom, prenom, dateNaissance, marie, enfants);				// Instanciation d'un client
						
						ContratAuto auto = new ContratAuto();				// Instanciation d'un contrat Auto
						
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir un chiffre entre 4 et 10
						 * si la saisie ne correspond pas, on redemande la saisie
						 */
					
						
						do { 
				
							try  {		
								System.out.print("Nombre de chevaux de votre voiture entre 4 et 10 : ");		
								chevaux = sc.nextInt();
								verfiSaisie=true;
							  }    
							  catch (InputMismatchException e){
									System.out.println("\n#############          Vous devez saisir un chiffre entre 4 et 10\n");
								  verfiSaisie=false;
							  }
						}while (verfiSaisie==false || (chevaux<4 || chevaux>10));
						
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir un chiffre entre 0,5 et 1.5
						 * si la saisie ne correspond pas, on redemande la saisie
						 */
		
						do { 
							Scanner sc3 = new Scanner( System.in );
							try  {		
								System.out.print("Le bonnus/Malus de votre voiture doit �tre compris entre 0,5 et 1,5 : ");
								 String chiffreDouble = sc3.next("^[0-9,]+$");					// verifie qu'il n'y ai que des chiffres et une virgule pour s�parateur d�cimal
								 chiffreDouble=chiffreDouble.replaceAll(",",".");				// remplace la virgule saisie par un point pour convertir en syst�me anglais
								 bonMal =Double.parseDouble(chiffreDouble);						// convertion de la sasie 'Strin' en valeur 'double'
									if (bonMal<0.5 || bonMal>1.5) {								// met un message d'erreur si la sasie d�passe les valeurs indiqu�es
										System.out.println("\n#############          Vous devez saisir un chiffre entre 0,5 et 1,5\n");
									}
								verfiSaisie=true;												// saisie valid�e
											
							
							  }    
							  catch (InputMismatchException e){									// si erreur non d�tect�e ci-dessus, on met un message g�n�rique
								  System.out.println("#############          Erreur de saisie : mettre uniquement des chiffre et s�parer les d�cimales avec une virgule et non un point");
								  verfiSaisie=false;											// saisie non valid�
							  }
						}while (verfiSaisie==false || (bonMal<0.5 || bonMal>1.5));				// si la sasie est invalide ou d�passe les valeurs autoris�e on redemande la saisie
						
						
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir Oui ou Non
						 * si la saisie ne correspond pas, on redemande la saisie
						 */				
						
						System.out.print("Nombre d�ann�es d�assurance : ");
						anAssur = sc.nextInt();
						while (anAssur<0) {					// si la saisie est inf�rieure � z�ro on redemande le nombre d'ann�e
		
							if (anAssur<0 ) {
								System.out.println("\n#############          Vous devez saisir un chiffre sup�rieur � 0\n");
							}
						
						}
						
						if (clients.isMarie()) {		// si le client est mari�/pacs� on demande si le conjoint est assur�
		
							char conjoint = 0;
							while (conjoint!='o' && conjoint!='O' && conjoint!='n' && conjoint!='N') {		// verifie l'utilisateur saisie bien un o,O,n,N
								
								System.out.print("Votre conjoint sera assur�  (O)ui ou (N)on: ");
								conjoint = sc.next().charAt(0);
								if (conjoint!='o' && conjoint!='O' && conjoint!='n' && conjoint!='N') {		// message d'erreur si la saisie est erron�e
									System.out.println("\n#############          Vous devez saisir O ou N");
								}
								if (conjoint=='o' || conjoint=='O'){				// si l'utilisateur saisie un o ou O on met aConjoint � true sinon c'est false 
									aConjoint = true;
								}
								else {
									aConjoint = false;
								}
							 
							}
						}
						
						
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir Oui ou Non
						 * si la saisie ne correspond pas, on redemande la saisie
						 */	
						if (clients.isEnfants()) {
							char enfants = 0;
		
							while (enfants!='o' && enfants!='O' && enfants!='n' && enfants!='N') {		// verifie l'utilisateur saisie bien un o,O,n,N
								
								System.out.print("Votre enfant sera assur� ?  (O)ui ou (N)on: ");
								enfants = sc.next().charAt(0);
								if (enfants!='o' && enfants!='O' && enfants!='n' && enfants!='N') {		// message d'erreur si la saisie est erron�e
									System.out.println("\n#############          Vous devez saisir O ou N");
								}
								if (enfants=='o' || enfants=='O'){				// si l'utilisateur saisie un o ou O on met aEnfants � true sinon c'est false 
									aEnfants = true;
								}
								else {
									aEnfants = false;
								}
							 
							}
						}
						
						// Instancie l'objet 'contratAuto' avec les valeurs saisie par l'utilisateur
						ContratAuto contratAuto = new ContratAuto(chevaux, bonMal, anAssur, aConjoint, aEnfants) ;
						
						// appelle la m�thode 'tarifs' pour calculer le tarif et retourne le r�sultat.
						double tarifAuto= CalculTarif.tarifsAuto(contratAuto.baseAuto, contratAuto.getMajChevauxTab(),contratAuto.getNbChevaux(), contratAuto.getReductionTab(), contratAuto.getConjointTab(), contratAuto.getEnfantsTab(), contratAuto.getBonsuMalus());
						
						// Affiche le tarif calcul�
						NumberFormat nf = new DecimalFormat("#.00");
						System.out.println("Le tarif est de : "+nf.format(tarifAuto)+ " euros");
						
						// Appelle de la m�thode 'imprimer' qui imprime le document � transmettre au client
						Imprimer.imprimerAuto(getNom(),  getPrenom(), tarifAuto, aConjoint , aEnfants );
						
						break;
						
					case 2 : 
						System.out.println("\n*************************    CONTRAT MOTO     ******************************\n");	

						ContratMoto moto = new ContratMoto();			// on instancie un contrat 'moto'
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir un chiffre entre 0,5 et 1.5
						 * si la saisie ne correspond pas, on redemande la saisie
						 */
		
						do { 
							Scanner sc3 = new Scanner( System.in );
							try  {		
								System.out.print("Le bonnus/Malus de votre voiture doit �tre compris entre 0,5 et 1,5 : ");
								 String chiffreDouble = sc3.next("^[0-9,]+$");					// verifie qu'il n'y ai que des chiffres et une virgule pour s�parateur d�cimal
								 chiffreDouble=chiffreDouble.replaceAll(",",".");				// remplace la virgule saisie par un point pour convertir en syst�me anglais
								 bonMal =Double.parseDouble(chiffreDouble);						// convertion de la sasie 'Strin' en valeur 'double'
									if (bonMal<0.5 || bonMal>1.5) {								// met un message d'erreur si la sasie d�passe les valeurs indiqu�es
										System.out.println("\n#############          Vous devez saisir un chiffre entre 0,5 et 1,5\n");
									}
								verfiSaisie=true;												// saisie valid�e
											
							
							  }    
							  catch (InputMismatchException e){									// si erreur non d�tect�e ci-dessus, on met un message g�n�rique
								  System.out.println("#############          Erreur de saisie : mettre uniquement des chiffre et s�parer les d�cimales avec une virgule et non un point");
								  verfiSaisie=false;											// saisie non valid�
							  }
						}while (verfiSaisie==false || (bonMal<0.5 || bonMal>1.5));				// si la sasie est invalide ou d�passe les valeurs autoris�e on redemande la saisie
						
						
						System.out.print("Quelle est la cylindr�e ? ");
						cylindree = sc.nextInt();
						while (cylindree<50 || cylindree>1900) {			// on boucle tant que la cylind�e est inf�rieure � 50 ou sup�rieure � 1900
		
							if (cylindree<50 || cylindree>1900) {
								System.out.println("\n#############          Vous devez saisir un chiffre entre 50 et 1900\n");
							}
							moto.setCylindree(cylindree); 					// on stocke le resultat
						}
						
					
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir Oui ou Non
						 * si la saisie ne correspond pas, on redemande la saisie
						 */				
						
						System.out.print("Nombre d�ann�es d�assurance : ");
						anAssur = sc.nextInt();
						while (anAssur<0) {				
		
							if (anAssur<0) {
								System.out.println("\n#############          Vous devez saisir un chiffre sup�rieur � 0\n");
							}
						
						}
						
					
						/*
						 * Construction de l'objet 'clients' qui sera accessible � tout moment dans le programme
						 */
						Clients clientsMoto = new Clients(nom, prenom, dateNaissance, marie, enfants);
						
						//ContratAuto moto = new ContratMoto();				// Instanciation d'un contrat Auto
						// Instancie l'objet 'contratAuto' avec les valeurs saisie par l'utilisateur
						ContratMoto contratMoto = new ContratMoto(cylindree, anAssur,bonMal) ;
					
						
						// appelle la m�thode 'tarifs' pour calculer le tarif et retourne le r�sultat.
						double tarifMoto= CalculTarif.tarifsMoto(contratMoto.baseMoto, contratMoto.getMajChevauxTab(), contratMoto.getBonMal(),contratMoto.getNbAnAssurance());
						
						// Affiche le tarif calcul�
						NumberFormat nf1 = new DecimalFormat("#.00");
						System.out.println("Le tarif est de : "+nf1.format(tarifMoto)+ " euros");
						
						// Appelle de la m�thode 'imprimer' qui imprime le document � transmettre au client
						Imprimer.imprimerMoto(getNom(),  getPrenom(), tarifMoto );
						
					
						//ContratAuto auto = new ContratAuto();
						break;
						
					case 3 : 
						System.out.println("\n*************************    CONTRAT HABITATION     ******************************\n");	
				
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir un chiffre sup�rieure � 10
						 * si la saisie ne correspond pas, on redemande la saisie
						 */
					
						do { 
							Scanner sc5 = new Scanner( System.in );
							try  {		
								System.out.print("Quelle est la surface ? ");		
								surface = sc5.nextInt();
								verfiSaisie=true;
							  }    
							  catch (InputMismatchException e){
								  System.out.println("\n#############          Vous devez saisir un chiffre sup�rieure ou �gale � 10\n");
								  verfiSaisie=false;
							  }
						}while (verfiSaisie==false || surface<10);
						
						
						
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir s'il a un garage ou non
						 * si la saisie ne correspond pas, on redemande la saisie
						 */

						char estGarage;
						do {
							System.out.print("Avez vous un garage (O)ui/(N)on ? : ");
							estGarage = sc.next().charAt(0);
							if (estGarage!='o' && estGarage!='O' && estGarage!='n' && estGarage!='N' ) {		// message d'erreur si la saisie est erron�e
								System.out.println("\n#############          Vous devez saisir O ou N");
							}
						}while (estGarage!='o' && estGarage!='O' && estGarage!='n' && estGarage!='N' );			// On boucle si la sasie n'est pas conforme
						if (estGarage=='o' || estGarage=='O'){
							garage=true;
						}
						else {
							garage=false;
						}
						
				
						/*
						 * Boucle qui pert de verifier si la saisie est conforme
						 * l'utilisateur doit choisir le nombre de personne du foyer
						 * si la saisie ne correspond pas, on redemande la saisie
						 */				

						do { 
							Scanner sc5 = new Scanner( System.in );
							try  {		
								System.out.print("Nombre de personne dans le foyer ? ");	
								String sasie_tmp = sc5.next("[0-9_]+");
								nbPersonneMaison = Integer.parseInt(sasie_tmp);
								verfiSaisie=true;
							  }    
							  catch (InputMismatchException e){
								  System.out.println("\n#############          Il doit y avoir au moins 1 personne dans le foyer\n");
								  verfiSaisie=false;
							  }
						}while (verfiSaisie==false || nbPersonneMaison<0);
						
						
						/*
						 * Construction de l'objet 'clients' qui sera accessible � tout moment dans le programme
						 */
						Clients clientsMaison = new Clients(nom, prenom, dateNaissance, marie, enfants);
						
						
						// Instancie l'objet 'maison' avec les valeurs saisie par l'utilisateur
						ContratMaison maison = new ContratMaison(surface, garage, nbPersonneMaison) ;
					
						
						// appelle la m�thode 'tarifs' pour calculer le tarif et retourne le r�sultat.
						double tarifMaison= CalculTarif.tarifsMaison(maison.baseMaison, maison.getMajSurfaceTab(), maison.getMajGrageTab() , maison.getMajNbPersooneSurface());
						
						// Affiche le tarif calcul�
						NumberFormat nf3 = new DecimalFormat("#.00");
						System.out.println("Le tarif est de : "+nf3.format(tarifMaison)+ " euros");
						
						// Appelle de la m�thode 'imprimer' qui imprime le document � transmettre au client
						Imprimer.imprimerMaison(getNom(),  getPrenom(), tarifMaison );
						
					
						//ContratAuto auto = new ContratAuto();
						break;
					default :
						System.out.println("#############          Vous devez faire un choix entre 1 et 3\n");
						
				}}
				 catch (InputMismatchException e){												// si une erreur n'a pas �t� d�tect�e plus haut, alors on met un message d'erreur g�n�rique
					  System.out.println("#############          Erreur de saisie, veuillez recommencer\n");
					  verfiSaisie=false;
			  }
		} while (verfiSaisie=false || (choix <1 || choix >3)) ;		// on reboucle le menu si le choix est diff�rent de 1,2,3
		
	
	}
	
	
	/*
	 * Decmaration des Getters et Setters
	 */

		public static String getNom() {
			return nom;
		}

		public static void setNom(String nom) {
			Saisie.nom = nom;
		}

		public static String getPrenom() {
			return prenom;
		}

		public static void setPrenom(String prenom) {
			Saisie.prenom = prenom;
		}

		public static String getDateNaissance() {
			return dateNaissance;
		}

		public static void setDateNaissance(String dateNaissance) {
			Saisie.dateNaissance = dateNaissance;
		}

		public static boolean isMarie() {
			return marie;
		}

		public static void setMarie(boolean marie) {
			Saisie.marie = marie;
		}

		public static boolean isEnfants() {
			return enfants;
		}

		public static void setEnfants(boolean enfants) {
			Saisie.enfants = enfants;
		}
}
