package assur_package;

/*
 * @author Mendi Michel
 * 
 * Ce constructeur sert � stocker les donn�es correspondant � un client
 */
public class Clients {

	private static String nom;						// variable pour le nom
	private static String prenom;					// variable pour le prenom
	private static String dateNaissance;			// variable pour la date de naissance
	private static boolean marie;					// variable pour connaitre la situation du client (mari�/pacs� ou non)
	private static boolean enfants;					// variable pour savoir si le client a des enfants ou non)
	
	
	/*
	 *  Construteur Clients.
	 *  Permet de stocker les donn�es du client  communues � tous les contrats
	 */
	Clients(String nom, String prenom, String dateNaissance, boolean marie, boolean enfants){
		this.nom=nom;
		this.prenom=prenom;
		this.dateNaissance=dateNaissance;
		this.marie=marie;
		this.enfants=enfants;
	}


	public static String getNom() {
		return nom;
	}


	public static void setNom(String nom) {
		Clients.nom = nom;
	}


	public static String getPrenom() {
		return prenom;
	}


	public static void setPrenom(String prenom) {
		Clients.prenom = prenom;
	}


	public static String getDateNaissance() {
		return dateNaissance;
	}


	public static void setDateNaissance(String dateNaissance) {
		Clients.dateNaissance = dateNaissance;
	}


	public static boolean isMarie() {
		return marie;
	}


	public static void setMarie(boolean marie) {
		Clients.marie = marie;
	}


	public static boolean isEnfants() {
		return enfants;
	}


	public static void setEnfants(boolean enfants) {
		Clients.enfants = enfants;
	}
}
