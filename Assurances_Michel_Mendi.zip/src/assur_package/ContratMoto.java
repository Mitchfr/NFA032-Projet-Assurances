package assur_package;

public  class ContratMoto{

	private int nbAnAssurance;						// variable du niombre d'ann�e d'assurance
	private int cylindree;							// variable pour la cylindr�e
	private double majChevauxTab;					// variable  de la majoration en chevaux fiscaux

	private double	bonMal;							// variable pour le bonus/malus
	


	int baseMoto = 30;								// tarif de base
	

	double [] majChevauxFiscaux = {1,1.1,1.2,1.3,1.4,1.5,1.6};			// majoration par rapport aux chevaux fiscaux
	int [] anAssur 				= {0,1,2,3,4,5,6};						// R�duction En euros Quel que soit	Le	nombre	de chevaux

	
/*
 * Definition du constructeur avec les variables � z�ro
 */
	 ContratMoto(){
			
			nbAnAssurance=0;
			cylindree=0;
			majChevauxTab=0;
	 }


	 /*
	  * Definition du constructeur avec les parametres saisies par l'utilisateur
	  */

	ContratMoto(int cylindree, int nbAnAssurance, double bonMal) {
		
		/*
		 *  Attribution du nombre de chevaux en fonction de la cylindree
		 *  
		 */
		int nbChevaux=0;
		if (cylindree>50 && cylindree <=200) {
			nbChevaux =1;
		}
		if (cylindree>200 && cylindree <=400) {
			nbChevaux =2;
		}
		if (cylindree>400 && cylindree <=600) {
			nbChevaux =3;
		}
		if (cylindree>600 && cylindree <=800) {
			nbChevaux =4;
		}
		if (cylindree>800 && cylindree <=1000) {
			nbChevaux =5;
		}
		if (cylindree>1000 && cylindree <=1200) {
			nbChevaux =6;
		}
		if (cylindree>1200 && cylindree <=1900) {
			nbChevaux =7;
		}
		
		if (nbAnAssurance>6) {										// si le nombre d'ann�e d'assurance d�passe 6 alors la reduction et la derni�re du tableau 'anAssur'
			this.nbAnAssurance=anAssur[6];							// recupere la valeur du nombre d'ann�e d'assurance
		}
		else {
			this.nbAnAssurance=anAssur[nbAnAssurance];				// recupere la valeur du nombre d'ann�e d'assurance
		}
	
		
		this.majChevauxTab=majChevauxFiscaux[nbChevaux-1];			// recupere la valeur dans le tableau 'majChevauxFiscaux'		
	
	
		this.cylindree=cylindree;									// recupere la valeur du nombre de chevaux
		this.bonMal=bonMal;
		
	}


	public int getNbAnAssurance() {
		return nbAnAssurance;
	}


	public void setNbAnAssurance(int nbAnAssurance) {
		this.nbAnAssurance = nbAnAssurance;
	}


	public int getCylindree() {
		return cylindree;
	}


	public void setCylindree(int cylindree) {
		this.cylindree = cylindree;
	}


	public double getMajChevauxTab() {
		return majChevauxTab;
	}


	public void setMajChevauxTab(double majChevauxTab) {
		this.majChevauxTab = majChevauxTab;
	}

	
	
	public double getBonMal() {
		return bonMal;
	}


	public void setBonMal(double bonMal) {
		this.bonMal = bonMal;
	}	
	
	

}
